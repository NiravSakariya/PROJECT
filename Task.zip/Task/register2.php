<form class="row login_form" method="post" id="contactForm" enctype="multipart/form-data">
    <div class="col-md-12 form-group">
        <input type="text" class="form-control" id="fname" name="fnm" placeholder="First Name *"
            onfocus="this.placeholder = ''" onblur="this.placeholder = 'First Name *'" required>
    </div>
    <div class="col-md-12 form-group">
        <input type="text" class="form-control" id="lname" name="lnm" placeholder="Last Name *"
            onfocus="this.placeholder = ''" onblur="this.placeholder = 'Last Name *'" required>
    </div>
    <div class="col-md-12 form-group">
        <input type="date" class="form-control" id="email" name="dateofbirth" placeholder="Date of Birth *"
            onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email *'" required>
    </div>
    <!-- <div class="col-md-12 form-group">
        <h4 class="gender-title">Gender</h4>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" id="inlineRadio1" value="Male" required>
            <label class="form-check-label" for="inlineRadio1">Male</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" id="inlineRadio2" value="Female">
            <label class="form-check-label" for="inlineRadio2">Female</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" id="inlineRadio3" value="Prefer not to say">
            <label class="form-check-label" for="inlineRadio3">Prefer not to say</label>
        </div>
    </div> -->

    <div class="col-md-12 form-group">
        <input type="number" class="form-control" id="pass" name="standard" placeholder="Standard *"
            onfocus="this.placeholder = '" onblur="this.placeholder = 'Password *'" required>
    </div>
    <div class="col-md-12 form-group">
        <input type="email" class="form-control" id="pho" name="emailid" placeholder="Email ID *"
            onfocus="this.placeholder = ''" onblur="this.placeholder = 'Phone No.'" required>
    </div>
    <!-- <div class="col-md-12 form-group">
        <input type="file" class="form-control" id="img" name="image" required>
    </div> -->
    <div class="col-md-12 form-group">
    <input type="number" class="form-control" id="pho" name="contact" placeholder="Contact *"
            onfocus="this.placeholder = ''" onblur="this.placeholder = 'Phone No.'" required>
    </div>

    <div class="col-md-12 form-group">
        <button type="submit" name="register" value="Register" class="primary-btn">Register</button>
        <a href="login#">Already Have An Account?</a>
    </div>
</form>