<form method="post" enctype="multipart/form-data">

<div class="row mb-3">
    <label class="col-sm-2 col-form-label">First name</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" name="firstname" placeholder="<?php echo $show1["st_id"]; ?>" id="inputEmail3" required>
    </div>
</div>

<div class="row mb-3">
    <label class="col-sm-2 col-form-label">Last name</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" name="lastname" id="inputPassword3" required>
    </div>
</div>

<div class="row mb-3">
    <label class="col-sm-2 col-form-label">Date of Birth</label>
    <div class="col-sm-10">
        <input type="date" class="form-control" name="dateofbirth" id="inputEmail3" required>
    </div>
</div>

<div class="col-md-12 form-group">
    <h4 class="gender-title">Gender</h4>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="inlineRadio1" value="Male" required>
        <label class="form-check-label" for="inlineRadio1">Male</label>
    </div>

    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="inlineRadio2" value="Female">
        <label class="form-check-label" for="inlineRadio2">Female</label>
    </div>

    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="inlineRadio3"
            value="Prefer not to say">
        <label class="form-check-label" for="inlineRadio3">Prefer not to say</label>
    </div>
</div>

<div class="row mb-3">
    <label class="col-sm-2 col-form-label">Standard</label>
    <div class="col-sm-10">
        <input type="number" class="form-control" name="standard" id="inputPassword3" required>
    </div>
</div>

<div class="row mb-3">
    <label class="col-sm-2 col-form-label">Email ID</label>
    <div class="col-sm-10">
        <input type="email" class="form-control" name="emailid" id="inputEmail3" required>
    </div>
</div>

<div class="row mb-3">
    <label class="col-sm-2 col-form-label">Image</label>
    <div class="col-sm-10">
        <input type="file" class="form-control" name="image" id="inputPassword3" required>
    </div>
</div>

<div class="row mb-3">
    <label class="col-sm-2 col-form-label">Contact</label>
    <div class="col-sm-10">
        <input type="tel" class="form-control" name="contact" id="inputPassword3" required>
    </div>
</div>

<center>
    <button type="submit" name="updatedata" class="btn btn-primary">Update</button>
</center>

</form>