<?php

        // Create a member function for insert data 
        public function insertalldata($data,$table)
        {
            $column=array_keys($data);
            $column1=implode(",",$column);
    
            $value=array_values($data);
            $value1=implode("','",$value);
    
            $insert="insert into $table($column1)values('$value1')";
            $exe=mysqli_query($this->connection,$insert);
            return $exe;
        }

        // Create a member function for Display data
        public function displayalldata($table)
        {
            $select="select * from $table";
            $exe=mysqli_query($this->connection,$select);
            while($fetch=mysqli_fetch_array($exe))
            {
                $arr[]=$fetch;
            }
            return $arr;
        }


        // insert data logic
        if(isset($_POST["Register"]))
        {
            $fnm=$_POST["firstname"];
            $lnm=$_POST["lastname"];
            $dob=$_POST["dateofbirth"];
            $gen=$_POST["gender"];
            $std=$_POST["standard"];
            $email=$_POST["emailid"];
            $tmp_name=$_FILES["image"]["tmp_name"];
            $path="uploads/Student Images/".$_FILES["image"]["name"];
            move_uploaded_file($tmp_name,$path);
            $con=$_POST["contact"];
            $data=array("firstname"=>$fnm,"lastname"=>$lnm,"dateofbirth"=>$dob,"gender"=>$gen,"standard"=>$std,"emailid"=>$email,"image"=>$path,"contact"=>$con);
            $chk=$this->insertalldata($data,'register_student');
            if($chk)
            {
                echo"<script>
                alert('Thanks For Register Here')
                window.location='/';
                </script>";
            }
        }

         // display registration student information logic
        $show=$this->displayalldata('register_student');
    ?>